===========================================ATTENTION===========================================
The fog code is created by Vocktile, All right reserved. You are not able to edit,
share and steal the code without Vocktile granted.

Vocktile DC: vocktile
mcpedl: vocktile
===========================================ATTENTION===========================================
The Shader is created by Yummysheep Studio, All right reserved. You are not able to edit,
share and steal the code without Yummysheep Studio granted. If we found that you have 
the action we mentioned, we must request you and the platform to remove it. If need, we 
may request it using law.

Yummysheep Studio Website: https://yummysheep.com
Term of use: https://yummysheep.com/term
==============================================End==============================================
